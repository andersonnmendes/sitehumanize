import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, Quote, Brain, Heart, Users, Video } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Ana Carolina",
      role: "Professora",
      company: "Setor Educacional",
      rating: 5,
      text: "O atendimento da Donna foi transformador na minha vida. Finalmente encontrei um espaço onde me sinto verdadeiramente acolhida e compreendida. Recomendo de coração!",
      type: "individual"
    },
    {
      name: "Ricardo Santos",
      role: "Empresário",
      company: "Setor Tecnológico",
      rating: 5,
      text: "A terapia online superou todas as minhas expectativas. A qualidade do atendimento é excepcional e a flexibilidade de horários fez toda a diferença na minha rotina.",
      type: "online"
    },
    {
      name: "Fernanda Lima",
      role: "Gestora de RH",
      company: "Multinacional",
      rating: 5,
      text: "Contratamos os serviços corporativos e o impacto foi incrível. Nossa equipe está mais motivada e o ambiente de trabalho melhorou significativamente.",
      type: "corporate"
    },
    {
      name: "Maria e João",
      role: "Casal",
      company: "Terapia Familiar",
      rating: 5,
      text: "A terapia familiar nos ajudou a reencontrar o diálogo e fortalecer nossos laços. O acolhimento e a sensibilidade da profissional foram fundamentais.",
      type: "family"
    }
  ];

  const stats = [
    { icon: Star, value: "5.0/5", label: "Avaliação Pacientes" },
    { icon: Users, value: "98%", label: "Pacientes Satisfeitos" },
    { icon: Brain, value: "200+", label: "Vidas Transformadas" },
    { icon: Heart, value: "4+", label: "Anos de Dedicação" }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'individual': return 'primary';
      case 'online': return 'wellness';
      case 'corporate': return 'secondary';
      case 'family': return 'accent';
      default: return 'primary';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'individual': return Brain;
      case 'online': return Video;
      case 'corporate': return Users;
      case 'family': return Heart;
      default: return Brain;
    }
  };

  return (
    <section id="testimonials" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            O que nossos <span className="bg-gradient-hero bg-clip-text text-transparent">Pacientes</span> dizem
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Histórias reais de transformação e crescimento pessoal. Cada depoimento representa uma jornada 
            única de autoconhecimento e bem-estar emocional.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card 
                key={index} 
                className="text-center p-6 border-0 shadow-soft hover:shadow-wellness transition-all duration-300 transform hover:scale-105 animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-0">
                  <Icon className="w-8 h-8 text-primary mx-auto mb-4" />
                  <div className="text-2xl font-bold text-foreground mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {testimonials.map((testimonial, index) => {
            const TypeIcon = getTypeIcon(testimonial.type);
            const colorClass = getTypeColor(testimonial.type);
            
            return (
              <Card 
                key={index} 
                className="p-8 border-0 shadow-soft hover:shadow-wellness transition-all duration-300 transform hover:scale-[1.02] animate-fade-in-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <CardContent className="p-0">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 bg-${colorClass} rounded-full flex items-center justify-center`}>
                        <TypeIcon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{testimonial.name}</h4>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                        <p className="text-sm font-medium text-primary">{testimonial.company}</p>
                      </div>
                    </div>
                    <Quote className="w-8 h-8 text-muted-foreground/30" />
                  </div>

                  {/* Rating */}
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-accent fill-current" />
                    ))}
                  </div>

                  {/* Text */}
                  <p className="text-muted-foreground leading-relaxed italic">
                    "{testimonial.text}"
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Social Proof Section */}
        <div className="bg-gradient-accent rounded-3xl p-12 text-center animate-fade-in-up">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-2xl lg:text-3xl font-bold text-foreground mb-6">
              Junte-se a centenas de pessoas que transformaram suas vidas
            </h3>
            <p className="text-muted-foreground mb-8 text-lg">
              Nossa abordagem humanizada tem ajudado pessoas a reencontrarem o equilíbrio emocional e 
              desenvolverem ferramentas para uma vida mais plena. Com <strong className="text-foreground">avaliações 
              5.0/5 estrelas</strong>, comprovamos diariamente nosso compromisso com seu bem-estar.
            </p>
            
            {/* Trust Indicators */}
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div className="bg-white rounded-xl p-6 shadow-soft">
                <div className="text-2xl font-bold text-primary mb-2">4+ anos</div>
                <div className="text-sm text-muted-foreground">Cuidando da saúde mental</div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-soft">
                <div className="text-2xl font-bold text-wellness mb-2">98%</div>
                <div className="text-sm text-muted-foreground">Taxa de satisfação dos pacientes</div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-soft">
                <div className="text-2xl font-bold text-accent mb-2">100%</div>
                <div className="text-sm text-muted-foreground">Compromisso com o acolhimento</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg">
                Agendar Primeira Consulta
              </Button>
              <Button variant="outline" size="lg">
                Conhecer Nossa Metodologia
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;