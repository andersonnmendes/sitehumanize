import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Award, 
  Users, 
  Heart, 
  Briefcase, 
  CheckCircle, 
  Star,
  Calendar,
  Target,
  Brain
} from "lucide-react";

const About = () => {
  const scrollToContact = () => {
    const section = document.getElementById('contact');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const stats = [
    { icon: Calendar, number: "4+", label: "Anos de Experiência", color: "primary" },
    { icon: Users, number: "200+", label: "Vidas Transformadas", color: "wellness" },
    { icon: Heart, number: "1k+", label: "Sessões Realizadas", color: "secondary" },
    { icon: Star, number: "5.0/5", label: "Avaliação Média", color: "accent" }
  ];

  const differentials = [
    {
      icon: Heart,
      title: "Abordagem Humanizada",
      description: "Acreditamos no poder do acolhimento e da escuta ativa. Cada pessoa é única e merece um atendimento personalizado e respeitoso."
    },
    {
      icon: Brain,
      title: "Técnicas Integradas",
      description: "Utilizamos diferentes abordagens psicológicas, adaptando as técnicas às necessidades específicas de cada paciente."
    },
    {
      icon: Target,
      title: "Foco no Bem-estar",
      description: "Nosso objetivo é promover saúde mental e qualidade de vida, oferecendo ferramentas para enfrentar desafios emocionais."
    },
    {
      icon: CheckCircle,
      title: "Atendimento Flexível",
      description: "Oferecemos modalidades presencial e online, com horários flexíveis para se adaptar à sua rotina e necessidades."
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Sobre a <span className="bg-gradient-hero bg-clip-text text-transparent">DONNA HUMANIZE</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Nossa missão é oferecer cuidado psicológico humanizado, baseado na empatia, acolhimento e 
            respeito pela singularidade de cada pessoa.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card 
                key={index} 
                className="text-center p-6 border-0 shadow-soft hover:shadow-wellness transition-all duration-300 transform hover:scale-105 animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-0">
                  <div className={`w-16 h-16 bg-${stat.color} rounded-full flex items-center justify-center mx-auto mb-4 shadow-elegant`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-2">{stat.number}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
          {/* Text Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h3 className="text-3xl font-bold text-foreground mb-6">
                Psicologia com Propósito e Acolhimento
              </h3>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  A <strong className="text-foreground">DONNA HUMANIZE</strong> nasceu da vontade de transformar 
                  vidas através de um atendimento psicológico verdadeiramente humano. Acreditamos que cada pessoa 
                  traz consigo uma história única e merece ser ouvida e acolhida.
                </p>
                <p>
                  Nossa abordagem vai além das técnicas tradicionais - incorporamos <strong className="text-foreground">
                  empatia, escuta ativa e respeito</strong> em cada sessão, criando um espaço seguro onde você pode 
                  se expressar livremente e encontrar caminhos para o seu bem-estar.
                </p>
                <p>
                  Com formação sólida e experiência prática, oferecemos atendimento tanto <strong className="text-foreground">
                  presencial quanto online</strong>, sempre mantendo o mesmo padrão de qualidade e cuidado humanizado.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="hero" size="lg" onClick={scrollToContact}>
                Conhecer Nossa Abordagem
              </Button>
              <Button variant="outline" size="lg">
                Ver Depoimentos
              </Button>
            </div>
          </div>

          {/* Differentials */}
          <div className="space-y-6 animate-fade-in-up delay-300">
            <h4 className="text-2xl font-bold text-foreground mb-6">Nossos Diferenciais</h4>
            {differentials.map((item, index) => {
              const Icon = item.icon;
              return (
                <div 
                  key={index} 
                  className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-soft hover:shadow-wellness transition-all duration-300"
                >
                  <div className="w-12 h-12 bg-gradient-hero rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-foreground mb-2">{item.title}</h5>
                    <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Mission & Values */}
        <div className="bg-white rounded-3xl p-12 shadow-soft animate-fade-in-up">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="w-16 h-16 bg-gradient-hero rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-bold text-foreground mb-3">Missão</h4>
              <p className="text-muted-foreground">
                Promover saúde mental e bem-estar através de um atendimento psicológico humanizado, 
                respeitando a singularidade de cada pessoa.
              </p>
            </div>
            
            <div>
              <div className="w-16 h-16 bg-gradient-wellness rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-bold text-foreground mb-3">Valores</h4>
              <p className="text-muted-foreground">
                Empatia, acolhimento, respeito, ética profissional e compromisso com o desenvolvimento 
                emocional e mental de nossos pacientes.
              </p>
            </div>
            
            <div>
              <div className="w-16 h-16 bg-gradient-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-accent-foreground" />
              </div>
              <h4 className="text-xl font-bold text-foreground mb-3">Visão</h4>
              <p className="text-muted-foreground">
                Ser referência em psicologia humanizada, contribuindo para uma sociedade 
                mais saudável emocionalmente e mentalmente.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;