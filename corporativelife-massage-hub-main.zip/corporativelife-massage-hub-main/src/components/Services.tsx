import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Video, Users, Heart, ArrowRight } from "lucide-react";
import therapyImage from "@/assets/donna-therapy.jpg";
import corporateImage from "@/assets/donna-corporate.jpg";
import onlineImage from "@/assets/donna-online.jpg";

const Services = () => {
  const scrollToContact = () => {
    const section = document.getElementById('contact');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    {
      icon: Brain,
      title: "Terapia Individual",
      description: "Atendimento psicológico personalizado para questões emocionais, ansiedade, depressão e desenvolvimento pessoal. Abordagem humanizada e acolhedora.",
      image: therapyImage,
      benefits: ["Autoconhecimento", "Redução da ansiedade", "Melhoria da autoestima", "Desenvolvimento emocional"],
      color: "primary"
    },
    {
      icon: Video,
      title: "Atendimento Online",
      description: "Sessões de psicoterapia através de videochamadas seguras, oferecendo flexibilidade e comodidade sem perder a qualidade do atendimento.",
      image: onlineImage,
      benefits: ["Flexibilidade de horários", "Conforto do lar", "Acesso facilitado", "Mesma qualidade terapêutica"],
      color: "wellness"
    },
    {
      icon: Users,
      title: "Psicologia Corporativa",
      description: "Programas de bem-estar mental para empresas, workshops sobre saúde mental e atendimento aos colaboradores para melhorar o ambiente de trabalho.",
      image: corporateImage,
      benefits: ["Reduz absenteísmo", "Melhora clima organizacional", "Previne burnout", "Aumenta produtividade"],
      color: "secondary"
    },
    {
      icon: Heart,
      title: "Acompanhamento Familiar",
      description: "Atendimento voltado para dinâmicas familiares, relacionamentos e comunicação entre membros da família, promovendo harmonia e compreensão.",
      image: therapyImage,
      benefits: ["Melhora comunicação", "Fortalece vínculos", "Resolve conflitos", "Harmonia familiar"],
      color: "accent"
    }
  ];

  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Nossas <span className="bg-gradient-hero bg-clip-text text-transparent">Abordagens</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Oferecemos atendimento psicológico humanizado, com diferentes modalidades para atender suas necessidades 
            específicas de forma acolhedora e profissional.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index} 
                className="group hover:shadow-wellness transition-all duration-300 transform hover:scale-[1.02] border-0 shadow-soft animate-fade-in-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <CardHeader className="p-0">
                  <div className="relative overflow-hidden rounded-t-xl h-48">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    <div className={`absolute top-4 left-4 w-12 h-12 bg-${service.color} rounded-full flex items-center justify-center shadow-elegant`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="p-6">
                  <CardTitle className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                    {service.title}
                  </CardTitle>
                  
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Benefits */}
                  <div className="space-y-2 mb-6">
                    {service.benefits.map((benefit, benefitIndex) => (
                      <div key={benefitIndex} className="flex items-center space-x-2">
                        <div className={`w-2 h-2 bg-${service.color} rounded-full`}></div>
                        <span className="text-sm text-muted-foreground">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full group/btn"
                    onClick={scrollToContact}
                  >
                    Agendar Consulta
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-accent rounded-3xl p-12 animate-fade-in-up">
          <h3 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
            Precisa de uma abordagem personalizada?
          </h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Cada pessoa é única, assim como suas necessidades emocionais. Desenvolvemos um plano terapêutico 
            personalizado para atender especificamente o que você está vivenciando.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg" onClick={scrollToContact}>
              Conversar com a Psicóloga
            </Button>
            <Button variant="outline" size="lg">
              Saber Mais Sobre Nossa Abordagem
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;