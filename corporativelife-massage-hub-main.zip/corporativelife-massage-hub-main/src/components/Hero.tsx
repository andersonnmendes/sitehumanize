import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Users, Calendar, Heart } from "lucide-react";
import heroImage from "@/assets/donna-hero.jpg";

const Hero = () => {
  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="pt-20 pb-16 bg-gradient-background min-h-screen flex items-center">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-primary">
                <Heart className="w-5 h-5 fill-current" />
                <span className="text-sm font-semibold">Cuidado humanizado desde 2020</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
                Psicologia
                <span className="bg-gradient-hero bg-clip-text text-transparent"> Humanizada</span>
                <br />
                e Acolhedora
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-xl leading-relaxed">
                Oferecemos atendimento psicológico personalizado e humanizado, tanto presencial quanto online. 
                Cuidamos da sua saúde mental com acolhimento e profissionalismo.
              </p>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <div>
                  <div className="font-semibold text-foreground">200+</div>
                  <div className="text-sm text-muted-foreground">Vidas transformadas</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-wellness" />
                <div>
                  <div className="font-semibold text-foreground">4+</div>
                  <div className="text-sm text-muted-foreground">Anos de experiência</div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5 text-accent fill-current" />
                <div>
                  <div className="font-semibold text-foreground">5.0/5</div>
                  <div className="text-sm text-muted-foreground">Avaliação média</div>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                variant="hero" 
                size="lg"
                onClick={() => scrollToSection('contact')}
                className="group"
              >
                Agendar Consulta
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => scrollToSection('services')}
              >
                Conhecer Abordagens
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="pt-8 border-t border-border">
              <p className="text-sm text-muted-foreground mb-4">Confiança e cuidado em cada atendimento:</p>
              <div className="flex flex-wrap gap-4 items-center opacity-60">
                <div className="px-4 py-2 bg-white rounded-lg shadow-soft border">
                  <span className="text-sm font-semibold text-muted-foreground">Terapia individual</span>
                </div>
                <div className="px-4 py-2 bg-white rounded-lg shadow-soft border">
                  <span className="text-sm font-semibold text-muted-foreground">Atendimento online</span>
                </div>
                <div className="px-4 py-2 bg-white rounded-lg shadow-soft border">
                  <span className="text-sm font-semibold text-muted-foreground">Psicologia clínica</span>
                </div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative animate-fade-in-up delay-300">
            <div className="relative overflow-hidden rounded-3xl shadow-wellness">
              <img
                src={heroImage}
                alt="Donna Humanize - Atendimento psicológico humanizado"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
            </div>
            
            {/* Floating card */}
            <div className="absolute -bottom-8 -left-8 bg-white p-6 rounded-2xl shadow-elegant border animate-glow">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-wellness rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">✓</span>
                </div>
                <div>
                  <div className="font-semibold text-foreground">Cuidado Humanizado</div>
                  <div className="text-sm text-muted-foreground">Atendimento com acolhimento</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;