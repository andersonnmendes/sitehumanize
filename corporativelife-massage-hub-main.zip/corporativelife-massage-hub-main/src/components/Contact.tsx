import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle, 
  Send,
  Building2,
  Calendar,
  Users,
  Instagram,
  Facebook,
  Linkedin
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    age: '',
    preferredType: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simular envio do formulário
    toast({
      title: "Mensagem enviada com sucesso!",
      description: "Entraremos em contato em breve para apresentar nossa proposta personalizada.",
    });

    // Limpar formulário
    setFormData({
      name: '',
      email: '',
      phone: '',
      age: '',
      preferredType: '',
      message: ''
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "WhatsApp",
      content: "(11) 9 9999-0000",
      action: "https://wa.me/5511999990000",
      color: "wellness"
    },
    {
      icon: MessageCircle,
      title: "Telefone",
      content: "(11) 9 9999-0000",
      action: "tel:+5511999990000",
      color: "primary"
    },
    {
      icon: Mail,
      title: "E-mail",
      content: "contato@donnahumanize.com",
      action: "mailto:contato@donnahumanize.com",
      color: "secondary"
    },
    {
      icon: MapPin,
      title: "Localização",
      content: "São Paulo - SP (Online e Presencial)",
      action: "#",
      color: "accent"
    }
  ];

  const therapyTypes = [
    { value: "individual", label: "Terapia Individual" },
    { value: "online", label: "Atendimento Online" },
    { value: "corporate", label: "Psicologia Corporativa" },
    { value: "family", label: "Acompanhamento Familiar" },
    { value: "consultation", label: "Consulta de Orientação" }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Entre em <span className="bg-gradient-hero bg-clip-text text-transparent">Contato</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Vamos juntos criar um espaço seguro para seu crescimento pessoal e bem-estar emocional. 
            Agende sua consulta e dê o primeiro passo para uma vida mais equilibrada.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Form */}
          <div className="lg:col-span-2 animate-fade-in-up">
            <Card className="border-0 shadow-wellness">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-foreground flex items-center space-x-2">
                  <Send className="w-6 h-6 text-primary" />
                  <span>Agendar Consulta</span>
                </CardTitle>
                <p className="text-muted-foreground">
                  Preencha o formulário abaixo e entraremos em contato para agendar sua primeira consulta.
                </p>
              </CardHeader>
              
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        Nome Completo *
                      </label>
                      <Input
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Seu nome completo"
                        required
                        className="transition-all duration-300 focus:shadow-soft"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        E-mail *
                      </label>
                      <Input
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="seu@email.com"
                        required
                        className="transition-all duration-300 focus:shadow-soft"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        Telefone/WhatsApp *
                      </label>
                      <Input
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="(11) 99999-9999"
                        required
                        className="transition-all duration-300 focus:shadow-soft"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        Idade
                      </label>
                      <Input
                        name="age"
                        value={formData.age}
                        onChange={handleInputChange}
                        placeholder="Sua idade"
                        className="transition-all duration-300 focus:shadow-soft"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      Tipo de Atendimento *
                    </label>
                    <select
                      name="preferredType"
                      value={formData.preferredType}
                      onChange={handleInputChange}
                      required
                      className="w-full p-3 border border-input rounded-md bg-background text-foreground transition-all duration-300 focus:shadow-soft focus:ring-2 focus:ring-ring focus:ring-offset-2"
                    >
                      <option value="">Selecione o tipo de atendimento</option>
                      {therapyTypes.map((type) => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      Mensagem
                    </label>
                    <Textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Conte-nos sobre o que está buscando na terapia, suas necessidades, preferências de horário, modalidade (presencial/online), etc."
                      rows={4}
                      className="transition-all duration-300 focus:shadow-soft"
                    />
                  </div>

                  <Button type="submit" variant="hero" size="lg" className="w-full group">
                    Solicitar Agendamento
                    <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Contact Info & Details */}
          <div className="space-y-8 animate-fade-in-up delay-300">
            {/* Contact Cards */}
            <div className="space-y-4">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <Card key={index} className="border-0 shadow-soft hover:shadow-wellness transition-all duration-300 transform hover:scale-[1.02]">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 bg-${info.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-foreground">{info.title}</h4>
                          <a 
                            href={info.action}
                            className="text-primary hover:text-primary/80 transition-colors"
                            target={info.action.startsWith('http') ? '_blank' : undefined}
                            rel={info.action.startsWith('http') ? 'noopener noreferrer' : undefined}
                          >
                            {info.content}
                          </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Business Hours */}
            <Card className="border-0 shadow-soft">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Clock className="w-6 h-6 text-primary" />
                  <h4 className="font-semibold text-foreground">Horário de Atendimento</h4>
                </div>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Segunda a Sexta:</span>
                    <span className="font-medium">8h às 18h</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábado:</span>
                    <span className="font-medium">8h às 14h</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Domingo:</span>
                    <span className="font-medium">Fechado</span>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-gradient-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    <strong className="text-foreground">Atendimentos:</strong> Realizamos serviços 
                    em horários flexíveis conforme necessidade do cliente.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card className="border-0 shadow-soft">
              <CardContent className="p-6">
                <h4 className="font-semibold text-foreground mb-4">Siga-nos nas Redes Sociais</h4>
                <div className="flex space-x-4">
                  <a 
                    href="#" 
                    className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center hover:bg-primary/80 transition-colors"
                  >
                    <Instagram className="w-5 h-5 text-white" />
                  </a>
                  <a 
                    href="#" 
                    className="w-10 h-10 bg-wellness rounded-lg flex items-center justify-center hover:bg-wellness/80 transition-colors"
                  >
                    <Facebook className="w-5 h-5 text-white" />
                  </a>
                  <a 
                    href="#" 
                    className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center hover:bg-secondary/80 transition-colors"
                  >
                    <Linkedin className="w-5 h-5 text-white" />
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;